/**
 * DTG Angel Service Worker Helpers
 *  - Loaded from background.js
 */

//Nothing to see here...yet