﻿globalThis.ImportBrowserPolyfill = true;
globalThis.StartBlazorBrowserExtension = true;
